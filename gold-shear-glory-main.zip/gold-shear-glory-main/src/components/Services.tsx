import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check } from "lucide-react";

const packages = [
  {
    name: "Classic Cut",
    price: "$45",
    features: [
      "Precision haircut",
      "Shampoo & conditioning",
      "Styling",
      "Hot towel finish",
    ],
  },
  {
    name: "Premium Package",
    price: "$75",
    popular: true,
    features: [
      "Precision haircut",
      "Beard trim & shaping",
      "Shampoo & conditioning",
      "Hot towel treatment",
      "Scalp massage",
      "Premium styling products",
    ],
  },
  {
    name: "Royal Treatment",
    price: "$120",
    features: [
      "Precision haircut",
      "Traditional straight razor shave",
      "Deluxe beard grooming",
      "Hot towel treatment",
      "Face mask",
      "Scalp & shoulder massage",
      "Premium styling",
    ],
  },
];

const services = [
  { name: "Haircut", price: "$40" },
  { name: "Beard Trim", price: "$25" },
  { name: "Straight Razor Shave", price: "$35" },
  { name: "Hot Towel Treatment", price: "$15" },
  { name: "Hair Color", price: "$60+" },
  { name: "Scalp Treatment", price: "$30" },
];

export const Services = () => {
  return (
    <section id="services" className="py-20 px-4 bg-secondary">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-primary">
            Services & Packages
          </h2>
          <p className="text-xl text-muted-foreground">
            Choose your perfect grooming experience
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {packages.map((pkg, index) => (
            <Card
              key={index}
              className={`relative bg-card border-2 transition-all duration-300 hover:scale-105 ${
                pkg.popular
                  ? "border-primary shadow-[0_0_40px_rgba(255,215,0,0.3)]"
                  : "border-border hover:border-primary"
              }`}
            >
              {pkg.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 bg-primary text-primary-foreground px-4 py-1 rounded-full text-sm font-semibold">
                  Most Popular
                </div>
              )}
              <CardHeader className="text-center pb-8">
                <CardTitle className="text-2xl text-primary mb-2">
                  {pkg.name}
                </CardTitle>
                <div className="text-5xl font-bold text-primary">
                  {pkg.price}
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-8">
                  {pkg.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-card-foreground">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button 
                  className={`w-full ${
                    pkg.popular
                      ? "bg-primary text-primary-foreground hover:bg-accent"
                      : "bg-secondary text-secondary-foreground border-2 border-primary hover:bg-primary hover:text-primary-foreground"
                  }`}
                >
                  Book Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-16">
          <h3 className="text-3xl font-bold text-center mb-8 text-primary">
            À La Carte Services
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 max-w-4xl mx-auto">
            {services.map((service, index) => (
              <Card
                key={index}
                className="bg-card border-border hover:border-primary transition-all duration-300"
              >
                <CardContent className="p-6 flex justify-between items-center">
                  <span className="text-card-foreground font-medium">
                    {service.name}
                  </span>
                  <span className="text-primary font-bold text-lg">
                    {service.price}
                  </span>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
