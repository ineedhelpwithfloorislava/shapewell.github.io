import { MapPin, Clock, Phone } from "lucide-react";

export const Footer = () => {
  return (
    <footer className="bg-card py-12 px-4 border-t border-border">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <h3 className="text-xl font-bold mb-4 text-primary">Location</h3>
            <div className="flex items-start gap-2 text-card-foreground">
              <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
              <div>
                <p>123 Main Street</p>
                <p>Downtown District</p>
                <p>City, ST 12345</p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4 text-primary">Hours</h3>
            <div className="flex items-start gap-2 text-card-foreground">
              <Clock className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
              <div className="space-y-1">
                <p>Monday - Friday: 9am - 8pm</p>
                <p>Saturday: 9am - 6pm</p>
                <p>Sunday: 10am - 4pm</p>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-bold mb-4 text-primary">Contact</h3>
            <div className="flex items-start gap-2 text-card-foreground">
              <Phone className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
              <div className="space-y-1">
                <p>Shop: (555) 100-2000</p>
                <p>Walk-ins welcome</p>
                <p>Appointments preferred</p>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center pt-8 border-t border-border">
          <p className="text-muted-foreground">
            © 2024 Elite Cuts & Grooming. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};
