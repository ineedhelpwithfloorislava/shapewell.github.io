import { Card, CardContent } from "@/components/ui/card";
import { Phone, Mail } from "lucide-react";
import barber1 from "@/assets/barber-1.jpg";
import barber2 from "@/assets/barber-2.jpg";
import barber3 from "@/assets/barber-3.jpg";

const barbers = [
  {
    name: "Marcus Johnson",
    specialty: "Classic Cuts & Beard Sculpting",
    experience: "15 years",
    bio: "Master barber specializing in traditional techniques with a modern twist. Known for precision fades and detailed beard work.",
    phone: "(555) 123-4567",
    email: "marcus@elitecuts.com",
    image: barber1,
  },
  {
    name: "Carlos Rodriguez",
    specialty: "Modern Styles & Color",
    experience: "10 years",
    bio: "Creative stylist who brings contemporary trends to life. Expert in color treatments and cutting-edge designs.",
    phone: "(555) 234-5678",
    email: "carlos@elitecuts.com",
    image: barber2,
  },
  {
    name: "Ryan Mitchell",
    specialty: "Traditional & Hot Towel Shaves",
    experience: "12 years",
    bio: "Traditional barber dedicated to the art of straight razor shaves and timeless grooming experiences.",
    phone: "(555) 345-6789",
    email: "ryan@elitecuts.com",
    image: barber3,
  },
];

export const Barbers = () => {
  return (
    <section id="barbers" className="py-20 px-4 bg-background">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 text-primary">
            Meet Our Master Barbers
          </h2>
          <p className="text-xl text-muted-foreground">
            Experienced professionals dedicated to your grooming excellence
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {barbers.map((barber, index) => (
            <Card 
              key={index}
              className="bg-card border-border hover:border-primary transition-all duration-300 hover:shadow-[0_0_30px_rgba(255,215,0,0.2)] overflow-hidden group"
            >
              <div className="relative h-80 overflow-hidden">
                <img
                  src={barber.image}
                  alt={barber.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
              </div>
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold mb-2 text-primary">
                  {barber.name}
                </h3>
                <p className="text-accent font-semibold mb-2">
                  {barber.specialty}
                </p>
                <p className="text-sm text-muted-foreground mb-4">
                  {barber.experience} of experience
                </p>
                <p className="text-card-foreground mb-6">
                  {barber.bio}
                </p>
                <div className="space-y-2 pt-4 border-t border-border">
                  <a 
                    href={`tel:${barber.phone}`}
                    className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
                  >
                    <Phone className="w-4 h-4" />
                    <span>{barber.phone}</span>
                  </a>
                  <a 
                    href={`mailto:${barber.email}`}
                    className="flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors"
                  >
                    <Mail className="w-4 h-4" />
                    <span>{barber.email}</span>
                  </a>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};
