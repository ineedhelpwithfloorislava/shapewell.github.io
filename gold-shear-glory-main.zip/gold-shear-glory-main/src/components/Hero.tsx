import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-barber.jpg";
import { Scissors } from "lucide-react";

export const Hero = () => {
  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative h-screen flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-black/70" />
      </div>
      
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <div className="flex justify-center mb-6">
          <Scissors className="w-16 h-16 text-primary" />
        </div>
        <h1 className="text-5xl md:text-7xl font-bold mb-6 text-primary">
          Elite Cuts & Grooming
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-card-foreground">
          Where Tradition Meets Excellence
        </p>
        <div className="flex gap-4 justify-center flex-wrap">
          <Button 
            size="lg"
            onClick={() => scrollToSection("services")}
            className="bg-primary text-primary-foreground hover:bg-accent font-semibold px-8"
          >
            View Services
          </Button>
          <Button 
            size="lg"
            variant="outline"
            onClick={() => scrollToSection("barbers")}
            className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-semibold px-8"
          >
            Meet Our Barbers
          </Button>
        </div>
      </div>
    </section>
  );
};
