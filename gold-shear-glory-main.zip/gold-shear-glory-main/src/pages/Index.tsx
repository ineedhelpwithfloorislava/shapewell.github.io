import { Hero } from "@/components/Hero";
import { Barbers } from "@/components/Barbers";
import { Services } from "@/components/Services";
import { Footer } from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Hero />
      <Barbers />
      <Services />
      <Footer />
    </div>
  );
};

export default Index;
